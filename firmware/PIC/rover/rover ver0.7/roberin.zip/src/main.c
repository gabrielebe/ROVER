/* 
 * File:   main.c
 * Author: Harpal
 *
 * Created on 25 settembre 2014, 10.24
 */

#include <stdio.h>
#include <stdlib.h>
#include "config.h"
#include "functions.h"

/*
 * 
 */
void writeValue( int position, int value);
void writeNumber(int number, int time);

int main(int argc, char** argv) {
    TRISB = 0x00;
    PORTB = 0x00;
    TRISD = 0x00;
    PORTD = 0x00;
    TRISA = 0xff;

    //*************//
    int temp;

    temp = read(0);

    while(1)
    {
        writeNumber(temp,10);
    }

    return (EXIT_SUCCESS);
}

void writeValue( int position, int value){
	/*Option to selcet the digit*/
	switch(position){
		case 3 : PORTD = 0b00001110;	//first digit
		break;
		case 2 : PORTD = 0b00001101;	//second digit
		break;
		case 1 : PORTD = 0b00001011;	//third digit
		break;
		case 0 : PORTD = 0b00000111;	//fourth digit
		break;
                default: PORTD = 0b00001111;    //turnOFF
	}
	/*displaying the value of the digit*/
	switch(value){
		case 0 : PORTB = ~0b00111111;	//0
		break;
		case 1 : PORTB = ~0b00000110;	//1
		break;
		case 2 : PORTB = ~0b01011011;	//2
		break;
		case 3 : PORTB = ~0b01001111;	//3
		break;
		case 4 : PORTB = ~0b01100110;	//4
		break;
		case 5 : PORTB = ~0b01101101;	//5
		break;
		case 6 : PORTB = ~0b01111101;	//6
		break;
		case 7 : PORTB = ~0b00000111;	//7
		break;
		case 8 : PORTB = ~0b01111111;	//8
		break;
		case 9 : PORTB = ~0b01101111;	//9
		break;
                default: PORTB = ~0b00000000;   //TURNOFF LED
	}
}

void writeNumber(int number, int time){
	int dig0,dig1,dig2,dig3, i,val;
	dig3 = (number/1000) - (number/10000)*10;
	dig2 = (number/100) - (number/1000)*10;
	dig1 = (number/10) - (number/100)*10;
	dig0 = (number) - (number/10)*10;
	for(i = 0; i < (time/5) ; i++ ){
	writeValue(3,dig0);
	__delay_us(1000);
	writeValue(2,dig1);
	__delay_us(1000);
	writeValue(1,dig2);
	__delay_us(1000);
	writeValue(0,dig3);
	__delay_us(1000);
	}
}