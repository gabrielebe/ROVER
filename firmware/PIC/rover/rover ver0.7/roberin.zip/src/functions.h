/* 
 * File:   functions.h
 * Author: Harpal
 *
 * Created on 25 settembre 2014, 10.49
 */

#ifndef FUNCTIONS_H
#define	FUNCTIONS_H

void ad_configuration(void);
int read(int);

#endif	/* FUNCTIONS_H */

