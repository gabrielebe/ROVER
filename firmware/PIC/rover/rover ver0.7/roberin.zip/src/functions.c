/* 
 * File:   functions.c
 * Author: Harpal
 *
 * Created on 25 settembre 2014, 10.50
 */

#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include <pic18f47j13.h>

void ad_configuration()
{
    //ADC module configuration
    ANCON0bits.PCFG0 = 0;            //A0-RA0 as analog pin
    ANCON0bits.PCFG1 = 0;            //A1-RC2 as analog pin
    ANCON0bits.PCFG2 = 1;            //Set pin as digital
    ANCON0bits.PCFG3 = 1;
    ANCON0bits.PCFG4 = 1;
    ANCON0bits.PCFG5 = 1;
    ANCON0bits.PCFG6 = 1;
    ANCON0bits.PCFG7 = 1;
    //*****************//
    ANCON1bits.PCFG8 = 1;
    ANCON1bits.PCFG9 = 1;
    ANCON1bits.PCFG10 = 1;
    ANCON1bits.PCFG11 = 1;
    ANCON1bits.PCFG12 = 1;
    //******************//
    ADCON0bits.VCFG0 = 0;            // Vref+ = AVdd
    ADCON0bits.VCFG1 = 0;            // Vref- = AVss
    //*****************//
    ADCON1bits.ADFM = 1;            //Right justification
    ADCON1bits.ACQT0 = 0;           // 16TAD is selected
    ADCON1bits.ACQT1 = 1;
    ADCON1bits.ACQT2 = 1;
    ADCON1bits.ADCS0 = 0;           //Fosc/2 is the A/D conversion clock
    ADCON1bits.ADCS1 = 0;
    ADCON1bits.ADCS2 = 0;

    

}
int read(int channel)
{
    int value = 0;
    ad_configuration();
    switch(channel){
        case '0' :  ADCON0bits.CHS0 = 0;            //select channel A0
                    ADCON0bits.CHS1 = 0;
                    ADCON0bits.CHS2 = 0;
                    ADCON0bits.CHS3 = 0;
                    break;
        case '1' :  ADCON0bits.CHS0 = 1;            //select channel A1
                    ADCON0bits.CHS1 = 0;
                    ADCON0bits.CHS2 = 0;
                    ADCON0bits.CHS3 = 0;
                    break;
        default: //error function
            break;
    }
    ADCON0bits.ADON = 1;            //Enabling the A/D module
    ADCON0bits.GO_DONE = 1;
    while(ADCON0bits.GO_DONE);
    value = ((ADRESH<<8) + ADRESL);
    ADCON0bits.ADON = 0;            //Disabling the A/D module
    return value;
}